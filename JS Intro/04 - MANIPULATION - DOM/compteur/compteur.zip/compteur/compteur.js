document.addEventListener('DOMContentLoaded', function () {

    let duree = prompt('Veuillez choisir un temps en seconde');
    let compteur = document.getElementById('compteur');
    let affichage = document.querySelector('header');

    if(isNaN(duree)) {
        duree = 0; // si la valeur n'est pas numérique
    }

    duree = Math.floor(duree); // si l'utilisateur saisie une valeur décimale

    function timer() {
        s = duree;
        m = 0;
        h = 0;

        if(s <= 0) {
            compteur.textContent = 'Temps écoulé !'
            affichage.classList.replace('bg-primary', 'bg-danger');
            // .classList : la liste des classes de l'élément
            // .replace('ancien', 'nouveau') : permet de remplacer une chaine par une autre 
            console.log(affichage.classList);

            // https://github.com/catdad/canvas-confetti
            confetti();
        } else {
            if(s > 59) {
                m = Math.floor(s / 60);
                s = s - (m * 60);
            }
            console.log(s);

            if(m > 59) {
                h = Math.floor(m / 60);
                m = m - (h * 60);
            }
            console.log(m);

            if(s < 10) {
                s = '0' + s;
            }
            if(m < 10) {
                m = '0' + m;
            }
            if(h < 10) {
                h = '0' + h;
            }

            compteur.innerHTML = '<b>' + h + ':' + m + ':' + s + '</b>';
            
        }
        duree--;
        setTimeout(timer, 1000); // exécute la fonction timer une fois avec une timer de 1000 milliseconde
        
    }
    // setInterval(timer, 1000);
    timer();

});
