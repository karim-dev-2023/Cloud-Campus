let divBoucle1 = document.getElementById('boucle1');
let divBoucle2 = document.getElementById('boucle2');
let divBoucle3 = document.getElementById('boucle3');
let divBoucle4 = document.getElementById('boucle4');
let divBoucle5 = document.getElementById('boucle5');

let tabCategories = ['Tshirts', 'Pantalons', 'Chaussures', 'Jupes', 'Robes', 'Pulls', 'Polos'];

let tailleTableau = tabCategories.length;

// Boucle 1
let contenu1 = '<ul>';
let i = 0;
while(i < tailleTableau) {
    contenu1 += '<li>' + tabCategories[i] + '</li>';
    i++;
}
contenu1 += '</ul>';
divBoucle1.innerHTML += contenu1;

// Boucle 2
let contenu2 = '<ul>';
for(i = 0; i < tailleTableau; i++) {
    contenu2 += '<li>' + tabCategories[i] + '</li>';
}
contenu2 += '</ul>';
divBoucle2.innerHTML += contenu2;

// Boucle 3
let contenu3 = document.createElement('ul');
for(indice in tabCategories) {
    let li = document.createElement('li');
    li.textContent = tabCategories[indice];
    contenu3.appendChild(li);
}
divBoucle3.appendChild(contenu3);

// Boucle 4
let contenu4 = document.createElement('ul');
for(valeur of tabCategories) {
    let li = document.createElement('li');
    li.textContent = valeur;
    contenu4.appendChild(li);
}
divBoucle4.appendChild(contenu4);


// Boucle5
let tableau = '<table class="table table-bordered">';
let chiffre = 0;
for(let i = 0; i < 10; i++) {
    tableau += '<tr>';
    for(let n = 0; n < 10; n++) {
        tableau += '<td>' + chiffre + '</td>';
        // tableau += '<td>' + (i * 10 + n) + '</td>';
        // tableau += '<td>' + i + n + '</td>';
        chiffre++;
    }
    tableau += '</tr>';
}


tableau += '</table>';
divBoucle5.innerHTML = tableau + '<hr';

tableau = '<table class="table table-bordered"><tr>';
for(let i = 0; i < 100; i++) {

    let red = Math.floor(Math.random() * 256);
    let green = Math.floor(Math.random() * 256);
    let blue = Math.floor(Math.random() * 256);
    let color = 'background-color: rgb(' + red + ', ' + green + ', ' + blue + ')';

    if(i % 10 == 0) {
        tableau += '</tr><tr>';
    }
    tableau += '<td style="' + color + '; color: white;">' + i + '</td>';
}
tableau += '</tr></table>';
divBoucle5.innerHTML += tableau + '<hr';

let tabColor = ['bg-white', '.bg-secondary-subtle', 'bg-secondary', 'bg-primary-subtle', 'bg-primary', 'bg-warning-subtle', 'bg-warning', 'bg-danger-subtle', 'bg-danger', 'bg-dark'];
tableau = '<table class="table table-bordered"><tr>';
for(let i = 0; i < 100; i++) {



    if(i % 10 == 0) {
        tableau += '</tr><tr>';
    }
    tableau += '<td class="' + tabColor[i % 10] + '">' + i + '</td>';
}
tableau += '</tr></table>';
divBoucle5.innerHTML += tableau + '<hr';